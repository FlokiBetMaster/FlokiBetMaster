import requests
from bs4 import BeautifulSoup

def obtener_partidos():
    url = "https://www.livescore.com/en/football/live/"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    try:
        res = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(res.text, "html.parser")
        partidos = []

        for match in soup.select("a.MatchRow_link__"):
            equipos = match.get_text(separator=" ").strip()
            if "HT" in equipos or "'" in equipos:
                partidos.append({
                    "equipos": equipos
                })
        return partidos

    except Exception as e:
        print("❌ Error en scraper:", e)
        return []
