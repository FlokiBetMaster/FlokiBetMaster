def generar_prediccion(partido):
    texto = partido["equipos"].lower()
    if "0 - 0" in texto or "0:0" in texto:
        return {"tipo": "Under 2.5", "confianza": 85}
    elif "1 - 1" in texto or "1:1" in texto:
        return {"tipo": "Draw", "confianza": 70}
    else:
        return {"tipo": "Over 2.5", "confianza": 65}
