from scraper import obtener_partidos
from predict import generar_prediccion
from odds import obtener_cuota
from stake import calcular_stake
from telegram import enviar_telegram

import time

print("🔄 FlokiBot en modo apuestas 24/7...")

while True:
    partidos = obtener_partidos()

    if partidos:
        for partido in partidos:
            prediccion = generar_prediccion(partido)
            if prediccion:
                cuota = obtener_cuota(partido)
                stake = calcular_stake(prediccion["confianza"])
                mensaje = f"""⚽ *Apuesta en Vivo*
📍 Partido: {partido['equipos']}
🎯 Predicción: {prediccion['tipo']}
🔥 Confianza: {prediccion['confianza']}%
💸 Cuota: {cuota}
🎲 Stake: {stake}

_Automatizado por FlokiBot_
"""
                enviar_telegram(mensaje)
    else:
        print("⚠️ No hay partidos activos.")

    time.sleep(300)
