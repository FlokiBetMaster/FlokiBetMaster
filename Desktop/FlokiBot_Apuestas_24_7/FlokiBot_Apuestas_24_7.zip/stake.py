def calcular_stake(confianza):
    if confianza >= 85:
        return 10
    elif confianza >= 70:
        return 7
    elif confianza >= 60:
        return 5
    return 3
